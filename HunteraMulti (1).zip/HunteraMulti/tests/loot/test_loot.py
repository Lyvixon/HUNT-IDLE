"""
Testes do script de venda loot (app/src/main/assets/loot.js) em Chromium real (Playwright).

A página simula o jogo: botão ≡ sem texto, menu com "Despachar loot", janela
"DESPACHAR LOOT" com "Despachar por X gp" e "Cancelar".

Execução:
    python3 tests/loot/test_loot.py
"""
import os
import sys
import tempfile
import time

from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
LOOT_JS = open(os.path.join(HERE, "..", "..", "app", "src", "main", "assets", "loot.js"), encoding="utf-8").read()

GOLD = "rgb(230, 180, 40)"
GREY = "rgb(128, 128, 128)"

# Ponte nativa simulada: o JS chama HunteraLoot.* e o teste responde pelo Python.
BRIDGE_JS = """
window.HunteraLoot = {
  log: function (s, m) { window.__log(s, m); },
  dispatched: function (ts) { window.__dispatched(ts); },
  nativeClick: function (x, y, vw, vh) { window.__native(x, y, vw, vh); }
};
"""


def build_html(btns, item="gold", por_closes=True, por_disabled=False, native_only=False):
    """btns: lista de (id, left, css) para os botões ≡ na metade inferior."""
    btn_divs = "\n".join(
        '<div id="%s" class="ic" style="position:absolute;left:%dpx;top:700px;width:48px;height:48px;'
        'box-sizing:border-box;cursor:pointer;%s"><svg width="20" height="20"></svg></div>' % (bid, left, css)
        for bid, left, css in btns
    )
    item_css = {
        "gold": "border:2px solid %s;" % GOLD,
        "grey": "border:2px solid %s;" % GREY,
    }.get(item, "")
    item_html = ""
    if item != "absent":
        item_html = (
            '<div id="item" style="padding:10px;cursor:pointer;%s">'
            '<span>Despachar loot</span><small>Venda automática</small></div>' % item_css
        )
    por_attr = " disabled" if por_disabled else ""
    return """<!doctype html><html><head><style>
html,body{{margin:0;width:1000px;height:800px;overflow:hidden;background:#222;position:relative}}
</style></head><body>
{btn_divs}
<div id="menu" style="display:none;position:absolute;left:80px;top:560px;background:#333;">
  {item_html}
  <div style="padding:10px;cursor:pointer">Vender algo</div>
</div>
<div id="win" style="display:none;position:absolute;left:300px;top:200px;width:400px;height:200px;background:#111">
  <div>DESPACHAR LOOT</div>
  <div style="position:absolute;bottom:10px;left:10px;right:10px">
    <button id="cancel">Cancelar</button>
    <button id="por"{por_attr} style="cursor:pointer"><span>Despachar por 1.000 gp</span></button>
  </div>
</div>
<script>
  var NATIVE_ONLY = {native_only};
  var PORCLOSES = {por_closes};
  window.__counts = {{menu: 0, item: 0, por: 0}};
  window.__clicked = [];
  function ok(e, force) {{ return (!NATIVE_ONLY || !force || e.isTrusted); }}
  document.querySelectorAll('.ic').forEach(function (b) {{
    b.addEventListener('click', function (e) {{
      if (!ok(e, true)) return;
      window.__counts.menu++; window.__clicked.push(b.id);
      document.getElementById('menu').style.display = 'block';
    }});
  }});
  var it = document.getElementById('item');
  if (it) it.addEventListener('click', function (e) {{
    if (!ok(e, true)) return;
    window.__counts.item++;
    document.getElementById('menu').style.display = 'none';
    document.getElementById('win').style.display = 'block';
  }});
  document.getElementById('por').addEventListener('click', function (e) {{
    window.__counts.por++;
    if (PORCLOSES) document.getElementById('win').style.display = 'none';
  }});
</script>
</body></html>""".format(
        btn_divs=btn_divs, item_html=item_html, por_attr=por_attr,
        native_only="true" if native_only else "false",
        por_closes="true" if por_closes else "false",
    )


class Session:
    def __init__(self, browser, html):
        self.page = browser.new_page(viewport={"width": 1000, "height": 800})
        self.logs = []
        self.dispatched = []
        self.pending_native = []
        self.page.expose_function("__log", lambda s, m: self.logs.append((s, m)))
        self.page.expose_function("__dispatched", lambda ts: self.dispatched.append(ts))
        self.page.expose_function("__native", lambda x, y, vw, vh: self.pending_native.append((x, y)))
        self.page.add_init_script(BRIDGE_JS)
        self.page.add_init_script(LOOT_JS)
        # goto (e não set_content) para que os init scripts rodem em todo documento.
        fd, path = tempfile.mkstemp(suffix=".html")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(html)
        self.page.goto("file://" + path)

    def enable(self):
        self.page.evaluate("() => window.__hunteraLoot.setEnabled(true, {intervalMs: 120000})")
        self.drive()

    def run_now(self):
        self.page.evaluate("() => window.__hunteraLoot.runNow()")
        self.drive()

    def drive(self, timeout_s=60):
        """Espera o ciclo terminar e executa os cliques nativos pedidos pelo script (como o Kotlin faria)."""
        t0 = time.time()
        self.page.wait_for_timeout(50)
        while time.time() - t0 < timeout_s:
            while self.pending_native:
                x, y = self.pending_native.pop(0)
                self.page.mouse.click(x, y)
            if not self.page.evaluate("() => window.__hunteraLoot.status().running") and not self.pending_native:
                return
            self.page.wait_for_timeout(100)
        raise TimeoutError("ciclo não terminou")

    def counts(self):
        return self.page.evaluate("() => window.__counts")

    def clicked(self):
        return self.page.evaluate("() => window.__clicked")

    def status(self):
        return self.page.evaluate("() => window.__hunteraLoot.status()")

    def steps(self):
        return [s for s, _ in self.logs]

    def messages(self):
        return [m for _, m in self.logs]

    def close(self):
        self.page.close()


RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (("  -> " + detail) if detail and not cond else ""))


def test_gold_button_full_flow(browser):
    s = Session(browser, build_html([("ok", 20, "border:3px solid %s;border-radius:8px;" % GOLD)]))
    s.enable()
    c = s.counts()
    check("dourado: ≡ clicado 1x", c["menu"] == 1, str(c))
    check("dourado: 'Despachar loot' clicado 1x", c["item"] == 1, str(c))
    check("dourado: 'Despachar por' clicado exatamente 1x", c["por"] == 1, str(c))
    check("dourado: logs 1/3, 2/3 e 3/3", {"1/3", "2/3", "3/3"} <= set(s.steps()), str(s.steps()))
    check("dourado: venda registrada só após janela fechar (ponte recebeu ts)", len(s.dispatched) == 1, str(s.dispatched))
    check("dourado: recarga de 1 h gravada", s.status()["lastDispatchAt"] > 0)

    # Recarga de 1 hora: mesmo com o botão ainda dourado, não clica de novo.
    s.run_now()
    check("recarga 1 h: nenhum novo clique", s.counts()["por"] == 1 and s.counts()["menu"] == 1, str(s.counts()))
    s.close()


def test_gold_via_srgb_shadow(browser):
    s = Session(browser, build_html([("sh", 20, "border:3px solid #555;box-shadow:0 0 8px 2px color(srgb 0.9 0.7 0.15 / 0.9);")]))
    s.enable()
    check("dourado na sombra com color(srgb): clicou no menu", s.counts()["menu"] == 1, str(s.counts()))
    s.close()


def test_non_gold_button_does_not_click(browser):
    s = Session(browser, build_html([("gr", 20, "border:3px solid %s;" % GREY)]))
    s.enable()
    s.run_now()
    s.run_now()
    s.run_now()
    c = s.counts()
    check("botão NÃO dourado: nenhum clique (menu 0)", c["menu"] == 0 and c["item"] == 0 and c["por"] == 0, str(c))
    check("botão NÃO dourado: nenhuma venda registrada", s.dispatched == [])
    diag_msgs = [m for st, m in s.logs if st == "diag" and "não encontrado" in m]
    check("aviso de diagnóstico limitado a 1 por 10 min", len(diag_msgs) == 1, str(len(diag_msgs)))
    s.close()


def test_tie_does_not_click(browser):
    css = "border:3px solid %s;" % GOLD
    s = Session(browser, build_html([("t1", 20, css), ("t2", 90, css)]))
    s.enable()
    check("empate entre dourados: não clica", s.counts()["menu"] == 0, str(s.counts()))
    check("empate: registra aviso", any("empate" in m for m in s.messages()))
    s.close()


def test_most_gold_wins(browser):
    s = Session(browser, build_html([
        ("pale", 20, "border:3px solid rgb(200,160,60);"),
        ("bright", 90, "border:3px solid rgb(255,200,0);"),
    ]))
    s.enable()
    check("entre dourados diferentes: clica o mais dourado", s.clicked() == ["bright"], str(s.clicked()))
    s.close()


def test_native_fallback_for_menu_and_item(browser):
    # Menu e item só respondem a toque real: o script deve cair no clique nativo.
    html = build_html([("ok", 20, "border:3px solid %s;" % GOLD)], native_only=True)
    s = Session(browser, html)
    s.enable()
    c = s.counts()
    check("fallback nativo: menu aberto por toque real", c["menu"] == 1, str(c))
    check("fallback nativo: item clicado por toque real", c["item"] == 1, str(c))
    check("fallback nativo: 'Despachar por' clicado 1x", c["por"] == 1, str(c))
    check("fallback nativo: venda registrada", len(s.dispatched) == 1)
    s.close()


def test_item_missing_pauses_two_minutes(browser):
    s = Session(browser, build_html([("ok", 20, "border:3px solid %s;" % GOLD)], item="absent"))
    s.enable()
    c = s.counts()
    check("item ausente: menu aberto 1x", c["menu"] == 1, str(c))
    check("item ausente: nenhum clique no item nem em 'Despachar por'", c["item"] == 0 and c["por"] == 0, str(c))
    paused_until = s.status()["pauseUntil"]
    check("item ausente: pausa de 2 min", paused_until - time.time() * 1000 > 100000, str(paused_until))
    s.run_now()
    check("durante a pausa: não reabre o menu", s.counts()["menu"] == 1, str(s.counts()))
    s.close()


def test_item_not_gold_pauses(browser):
    s = Session(browser, build_html([("ok", 20, "border:3px solid %s;" % GOLD)], item="grey"))
    s.enable()
    c = s.counts()
    check("item cinza: não clica no item", c["item"] == 0, str(c))
    check("item cinza: pausa (não sobrepõe ciclos)", s.status()["pauseUntil"] > time.time() * 1000)
    s.close()


def test_window_not_closing_never_double_clicks(browser):
    s = Session(browser, build_html([("ok", 20, "border:3px solid %s;" % GOLD)], por_closes=False))
    s.enable()
    check("janela não fecha: 'Despachar por' clicado 1x", s.counts()["por"] == 1, str(s.counts()))
    check("janela não fecha: venda NÃO registrada", s.dispatched == [])
    s.run_now()
    check("janela não fecha: segunda passada NÃO clica de novo", s.counts()["por"] == 1, str(s.counts()))
    s.close()


def test_disabled_dispatch_button(browser):
    s = Session(browser, build_html([("ok", 20, "border:3px solid %s;" % GOLD)], por_disabled=True))
    s.enable()
    check("'Despachar por' desabilitado: não clica", s.counts()["por"] == 0, str(s.counts()))
    s.close()


def test_color_parsing(browser):
    s = Session(browser, "<html><body></body></html>")
    cases = [
        ("rgb(230, 180, 40)", True),
        ("rgba(230, 180, 40, 0.5)", True),
        ("rgb(230 180 40 / 50%)", True),
        ("color(srgb 0.9 0.7 0.15)", True),
        ("color(srgb 0.9 0.7 0.15 / 0.5)", True),
        ("rgb(128, 128, 128)", False),
        ("rgb(255, 0, 0)", False),                 # vermelho: matiz 0
        ("rgb(255, 120, 0)", False),               # laranja: matiz ~24
        ("rgba(230, 180, 40, 0.1)", False),        # quase transparente
        ("rgb(60, 45, 20)", False),                # escuro: brilho < 0.6
        ("rgb(230, 200, 200)", False),             # pouco saturado
        ("transparent", False),
        ("none", False),
        ("oklch(0.8 0.1 90)", False),              # não suportado: ignorado
    ]
    results = s.page.evaluate("(cases) => cases.map(c => window.__hunteraLoot._internal.goldScore(c[0]) > 0)", [list(c) for c in cases])
    for (val, expected), got in zip(cases, results):
        check("cor %r dourada=%s" % (val, expected), got == expected, "got %s" % got)
    # limites da faixa de matiz
    # matiz = 60*(g-b)/(r-b) quando r é o máximo: g=103 -> ~30.9°; g=110 -> ~33°
    bounds = s.page.evaluate("""() => {
      const g = window.__hunteraLoot._internal.goldScore;
      return { h31: g('rgb(200, 103, 0)'), h33: g('rgb(200, 110, 0)') };
    }""")
    check("limite de matiz: 31° fora", bounds["h31"] == 0, str(bounds))
    check("limite de matiz: 33° dentro", bounds["h33"] > 0, str(bounds))
    s.close()


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        try:
            test_gold_button_full_flow(browser)
            test_gold_via_srgb_shadow(browser)
            test_non_gold_button_does_not_click(browser)
            test_tie_does_not_click(browser)
            test_most_gold_wins(browser)
            test_native_fallback_for_menu_and_item(browser)
            test_item_missing_pauses_two_minutes(browser)
            test_item_not_gold_pauses(browser)
            test_window_not_closing_never_double_clicks(browser)
            test_disabled_dispatch_button(browser)
            test_color_parsing(browser)
        finally:
            browser.close()
    failed = [r for r in RESULTS if not r[1]]
    print("\n%d/%d testes passaram" % (len(RESULTS) - len(failed), len(RESULTS)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
