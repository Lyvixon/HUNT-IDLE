# Huntera Multi (Android)

App com 4 WebViews, cada uma com perfil (cookies/localStorage) próprio, para logar em 4 contas do huntera.com.br.
Grade: 1 (tela cheia), 2 (empilhadas), 4 (2x2).

## Como abrir
1. Android Studio (Ladybug ou mais novo) > File > Open > pasta HunteraMulti.
2. Aguarde o Gradle sincronizar e clique em Run com um celular Android 8+ (API 26).
3. Requer Android System WebView atualizado (Play Store).

## Observações
- Os nomes exatos da API de perfis do androidx.webkit (WebViewCompat.setProfile, WebViewFeature.MULTI_PROFILE) dependem da versão da biblioteca. Se o build reclamar, ajuste a versão em app/build.gradle.kts ou os nomes conforme a documentação do androidx.webkit.
- Não testado em aparelho real.
