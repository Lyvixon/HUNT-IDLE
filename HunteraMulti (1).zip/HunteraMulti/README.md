# Huntera Multi (Android)

App com 4 WebViews, cada uma com perfil (cookies/localStorage) próprio, para logar em 4 contas do huntera.com.br.
Grade: 1 (tela cheia), 2 (empilhadas), 4 (2x2).

## Como abrir
1. Android Studio (Ladybug ou mais novo) > File > Open > pasta HunteraMulti.
2. Aguarde o Gradle sincronizar e clique em Run com um celular Android 8+ (API 26).
3. Requer Android System WebView atualizado (Play Store).

## Observações
- Os nomes exatos da API de perfis do androidx.webkit (WebViewCompat.setProfile, WebViewFeature.MULTI_PROFILE) dependem da versão da biblioteca. Se o build reclamar, ajuste a versão em app/build.gradle.kts ou os nomes conforme a documentação do androidx.webkit.
- Não testado em aparelho real.

## Venda loot (automação)
Botão **Loot** na barra lateral. Em cada conta, marque ON/OFF e defina o intervalo de verificação (padrão 120 s).

Fluxo, verificado a cada intervalo na página do jogo (`app/src/main/assets/loot.js`):
1. Botão ≡ dourado (sem texto, 24–100 px, metade inferior) → clique.
2. Item "Despachar loot" dourado no menu → clique.
3. Janela "DESPACHAR LOOT" → um único clique em "Despachar por X gp".
4. Só registra a venda quando a janela fecha; depois, recarga de 1 hora.

Regras de segurança: clique sintético (eventos de DOM) com reserva em toque real (`LootBridge.nativeClick`) só para menu e item; "Despachar por" é clicado uma vez e nunca repetido; botão empatado não é clicado; se o item não aparece após abrir o menu, pausa de 2 min.

Registros por etapa (1/3, 2/3, 3/3) vão para o Logcat (tag `HunteraLoot`) e para a janela Loot. Avisos de diagnóstico saem no máximo a cada 10 min.

### Testes
Os testes rodam o `loot.js` no Chromium real (Playwright) com uma página que imita o jogo:
```
pip install playwright && python -m playwright install chromium
python3 tests/loot/test_loot.py
```
Inclui o caso de botão não dourado (não deve clicar), empate, clique nativo de reserva, item ausente, janela que não fecha e recarga.
