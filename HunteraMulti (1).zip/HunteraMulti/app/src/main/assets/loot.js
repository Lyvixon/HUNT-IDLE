/*
 * Huntera Multi - automação "Venda loot".
 * Injetado em cada WebView do jogo. Idempotente: se window.__hunteraLoot já existir, não faz nada.
 *
 * Fluxo (verificado a cada 2 min por padrão):
 *   1/3  botão ≡ dourado (sem texto, 24-100 px, metade inferior) -> clique -> item "Despachar loot" dourado
 *   2/3  janela "DESPACHAR LOOT" aberta -> UM clique em "Despachar por X gp"
 *   3/3  janela fechou -> venda registrada, recarga de 1 h
 */
(function () {
  'use strict';
  if (window.__hunteraLoot) return;

  var BRIDGE = window.HunteraLoot || null; // ponte nativa (Android); null em teste no navegador
  var COOLDOWN_MS = 60 * 60 * 1000;        // recarga de 1 h após despacho confirmado
  var PAUSE_MS = 2 * 60 * 1000;            // pausa quando o item não aparece após abrir o menu
  var DIAG_EVERY_MS = 10 * 60 * 1000;      // avisos de diagnóstico no máximo a cada 10 min
  var WINDOW_CLOSE_WAIT_MS = 15000;

  var st = {
    enabled: false,
    running: false,        // trava: não sobrepor ciclos
    timer: null,
    intervalMs: 120000,
    lastDispatchAt: 0,
    clickedDispatchAt: 0,  // "Despachar por" já foi clicado; nunca clicar de novo
    pauseUntil: 0,
    diagAt: {}
  };

  // ---------- utilidades ----------

  function now() { return Date.now(); }
  function norm(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function log(step, msg) {
    try { if (BRIDGE) BRIDGE.log(step || '', String(msg)); } catch (e) { /* ignora */ }
    try { console.log('[HunteraLoot] ' + (step || '') + ' ' + msg); } catch (e) { /* ignora */ }
  }

  // Avisos de diagnóstico: no máximo um por chave a cada 10 minutos.
  function diag(key, msg) {
    var t = now();
    if (st.diagAt[key] && t - st.diagAt[key] < DIAG_EVERY_MS) return;
    st.diagAt[key] = t;
    log('diag', msg);
  }

  function pause(key, msg) {
    st.pauseUntil = now() + PAUSE_MS;
    diag(key, msg + ' (pausa de 2 min)');
  }

  async function waitFor(fn, timeoutMs) {
    var end = now() + timeoutMs;
    while (now() < end) {
      if (!st.enabled) return null;
      var v = fn();
      if (v) return v;
      await sleep(250);
    }
    return fn() || null;
  }

  // ---------- cores ----------

  var NUM = '[-+]?(?:\\d+\\.?\\d*|\\.\\d+)(?:e[-+]?\\d+)?%?';

  // Lê rgb(), rgba(), color(srgb ...) e devolve {r,g,b,a} em 0-255 / 0-1, ou null.
  function parseColor(str) {
    if (!str) return null;
    var s = String(str).trim().toLowerCase();
    if (s === 'none' || s === 'transparent') return null;
    var m = s.match(/^(rgba?|color)\((.*)\)$/);
    if (!m) return null;
    var srgb = m[1] === 'color';
    var body = m[2];
    if (srgb) {
      var sm = body.match(/^\s*srgb\s+(.*)$/);
      if (!sm) return null;              // ex.: srgb-linear, lab, oklch: não tratados
      body = sm[1];
    }
    var parts = body.split('/');
    var chans = parts[0].replace(/,/g, ' ').trim().split(/\s+/);
    var alphaTok = parts.length > 1 ? parts[1].trim() : (chans.length > 3 ? chans[3] : null);
    if (chans.length < 3) return null;
    var re = new RegExp('^' + NUM + '$');
    for (var i = 0; i < 3; i++) if (!re.test(chans[i])) return null;
    function chan(t) {
      return t.charAt(t.length - 1) === '%' ? parseFloat(t) * 2.55 : (srgb ? parseFloat(t) * 255 : parseFloat(t));
    }
    var r = chan(chans[0]), g = chan(chans[1]), b = chan(chans[2]);
    var a = 1;
    if (alphaTok !== null && alphaTok !== undefined && alphaTok !== '') {
      a = alphaTok.charAt(alphaTok.length - 1) === '%' ? parseFloat(alphaTok) / 100 : parseFloat(alphaTok);
    }
    if ([r, g, b, a].some(isNaN)) return null;
    return {
      r: clamp(r, 0, 255), g: clamp(g, 0, 255), b: clamp(b, 0, 255), a: clamp(a, 0, 1)
    };
  }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, h = 0;
    if (d > 0) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    return { h: h, s: max === 0 ? 0 : d / max, v: max };
  }

  // Dourado: matiz 32-62, saturação >= 0.4, brilho >= 0.6. Devolve a força (s*v*alpha) ou 0.
  function goldScore(colorStr) {
    var c = parseColor(colorStr);
    if (!c || c.a < 0.2) return 0;
    var hsv = rgbToHsv(c.r, c.g, c.b);
    if (hsv.h >= 32 && hsv.h <= 62 && hsv.s >= 0.4 && hsv.v >= 0.6) {
      return hsv.s * hsv.v * c.a;
    }
    return 0;
  }

  function shadowColors(boxShadow) {
    if (!boxShadow || boxShadow === 'none') return [];
    var out = [];
    var re = /(rgba?\([^)]*\)|color\([^)]*\))/g, m;
    while ((m = re.exec(boxShadow))) out.push(m[1]);
    return out;
  }

  function sideColors(cs, out) {
    ['Top', 'Right', 'Bottom', 'Left'].forEach(function (side) {
      if (parseFloat(cs['border' + side + 'Width']) > 0 && cs['border' + side + 'Style'] !== 'none') {
        out.push(cs['border' + side + 'Color']);
      }
    });
  }

  // Cores de borda, contorno, sombra e pseudo-elementos (::before/::after).
  // extended = true também considera cor do texto e fundo (usado no item de menu).
  function elementColors(el, extended) {
    var cs = getComputedStyle(el);
    var out = [];
    sideColors(cs, out);
    if (parseFloat(cs.outlineWidth) > 0 && cs.outlineStyle !== 'none') out.push(cs.outlineColor);
    out = out.concat(shadowColors(cs.boxShadow));
    ['::before', '::after'].forEach(function (ps) {
      var p = getComputedStyle(el, ps);
      if (!p || !p.content || p.content === 'none' || p.content === 'normal') return;
      sideColors(p, out);
      if (parseFloat(p.outlineWidth) > 0 && p.outlineStyle !== 'none') out.push(p.outlineColor);
      out = out.concat(shadowColors(p.boxShadow));
      out.push(p.backgroundColor);
    });
    if (extended) { out.push(cs.color); out.push(cs.backgroundColor); }
    return out;
  }

  function elementGoldScore(el, extended) {
    var best = 0;
    elementColors(el, extended).forEach(function (c) { best = Math.max(best, goldScore(c)); });
    return best;
  }

  function isVisible(el) {
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0.05;
  }

  function selfDisabled(el) {
    if (el.disabled === true) return true;
    if (el.getAttribute && (el.getAttribute('aria-disabled') === 'true' || el.hasAttribute('disabled'))) return true;
    var cls = (el.getAttribute && el.getAttribute('class')) || '';
    return /(^|[\s_-])disabled($|[\s_-])/i.test(cls);
  }

  function isDisabledChain(el, clickable) {
    for (var e = el; e && e !== document.body; e = e.parentElement) {
      if (selfDisabled(e)) return true;
      if (e === clickable) break;
    }
    return false;
  }

  var CLICKABLE_SEL = 'button,a,[role="button"],[role="menuitem"],[onclick],input[type="button"],input[type="submit"]';

  // Sobe do texto/ícone até o elemento clicável. Vence o primeiro botão/link/role=button;
  // senão, o ancestral mais alto com cursor pointer (cursor é herdado, então o texto sozinho não serve).
  function clickableOf(el) {
    var e = el, pointerTop = null;
    for (var i = 0; i < 6 && e && e !== document.body; i++, e = e.parentElement) {
      if (e.matches && e.matches(CLICKABLE_SEL)) return e;
      if (getComputedStyle(e).cursor === 'pointer') pointerTop = e;
    }
    return pointerTop || el;
  }

  // Botão ≡ dourado: sem texto, 24-100 px, metade inferior da tela.
  // Devolve {el, score} | {tie: true} | null.
  function findGoldenButton() {
    var vh = window.innerHeight, vw = window.innerWidth;
    var byRect = new Map();
    var all = document.querySelectorAll('body *');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      var r = el.getBoundingClientRect();
      if (r.width < 24 || r.width > 100 || r.height < 24 || r.height > 100) continue;
      if (r.top < vh / 2) continue;
      if (r.bottom > vh || r.right > vw || r.left < 0) continue;
      if ((el.textContent || '').trim() !== '') continue;
      if (!isVisible(el) || isDisabledChain(el, el)) continue;
      var score = elementGoldScore(el, false);
      if (score <= 0) continue;
      var key = [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)].join(',');
      var prev = byRect.get(key);
      if (!prev || prev.el.contains(el)) byRect.set(key, { el: el, score: score });
    }
    var sorted = Array.from(byRect.values()).sort(function (a, b) { return b.score - a.score; });
    // Elementos aninhados com o mesmo botão contam como um só.
    var distinct = [];
    sorted.forEach(function (c) {
      for (var j = 0; j < distinct.length; j++) {
        if (distinct[j].el.contains(c.el) || c.el.contains(distinct[j].el)) return;
      }
      distinct.push(c);
    });
    if (distinct.length === 0) return null;
    if (distinct.length > 1 && distinct[0].score - distinct[1].score < 0.02) return { tie: true };
    return distinct[0];
  }

  // Janela "DESPACHAR LOOT": menor elemento que contém "despachar loot", "despachar por" e "cancelar".
  function findDispatchWindow() {
    var best = null, bestLen = Infinity;
    var all = document.querySelectorAll('body *');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      var t = norm(el.textContent);
      if (t.length >= bestLen) continue;
      if (t.indexOf('despachar loot') < 0 || t.indexOf('despachar por') < 0 || t.indexOf('cancelar') < 0) continue;
      if (!isVisible(el)) continue;
      best = el; bestLen = t.length;
    }
    return best;
  }

  // Item "Despachar loot" do menu (aceita subtítulo). Ignora a janela já aberta.
  function findMenuItem() {
    var win = findDispatchWindow();
    var found = null;
    var all = document.querySelectorAll('body *');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (win && win.contains(el)) continue;          // título da janela aberta
      if (!norm(el.textContent).startsWith('despachar loot')) continue;
      var childHas = false;
      for (var k = 0; k < el.children.length; k++) {
        if (norm(el.children[k].textContent).startsWith('despachar loot')) { childHas = true; break; }
      }
      if (childHas || !isVisible(el)) continue;
      var clickable = clickableOf(el);
      var chain = [];
      for (var e = el; e; e = e.parentElement) { chain.push(e); if (e === clickable) break; }
      var gold = chain.some(function (x) { return elementGoldScore(x, true) > 0; });
      var disabled = isDisabledChain(el, clickable);
      var cand = { el: el, clickable: clickable, gold: gold, disabled: disabled };
      if (gold && !disabled) return cand;
      if (!found) found = cand;
    }
    return found;
  }

  // Botão "Despachar por X gp", dentro do contêiner da janela.
  function findDispatchButton(win) {
    var fallback = null;
    var all = win.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (!norm(el.textContent).startsWith('despachar por') || !isVisible(el)) continue;
      var childHas = false;
      for (var k = 0; k < el.children.length; k++) {
        if (norm(el.children[k].textContent).startsWith('despachar por')) { childHas = true; break; }
      }
      if (childHas) continue;
      var clickable = clickableOf(el);
      if (!win.contains(clickable)) continue;
      var cand = { el: el, clickable: clickable, disabled: isDisabledChain(el, clickable) };
      if (clickable.matches && clickable.matches(CLICKABLE_SEL) && !cand.disabled) return cand;
      if (!fallback && !cand.disabled) fallback = cand;
    }
    return fallback;
  }

  // ---------- cliques ----------

  // Clique completo por eventos de DOM.
  function fire(el, x, y) {
    var base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0 };
    var P = window.PointerEvent || MouseEvent;
    var seq = [
      ['pointerdown', P, Object.assign({}, base, { buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true })],
      ['mousedown', MouseEvent, Object.assign({}, base, { buttons: 1 })],
      ['pointerup', P, Object.assign({}, base, { buttons: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true })],
      ['mouseup', MouseEvent, Object.assign({}, base, { buttons: 0 })],
      ['click', MouseEvent, Object.assign({}, base, { buttons: 0 })]
    ];
    seq.forEach(function (s) {
      try { el.dispatchEvent(new s[1](s[0], s[2])); } catch (e) { /* ignora */ }
    });
  }

  function clickSynthetic(el) {
    var r = el.getBoundingClientRect();
    fire(el, r.left + r.width / 2, r.top + r.height / 2);
  }

  // Clique real (toque nativo) no centro do elemento, via ponte Android.
  function clickNative(el) {
    if (!BRIDGE || !BRIDGE.nativeClick) return false;
    var r = el.getBoundingClientRect();
    try {
      BRIDGE.nativeClick(r.left + r.width / 2, r.top + r.height / 2, window.innerWidth, window.innerHeight);
      return true;
    } catch (e) { return false; }
  }

  // ---------- etapas ----------

  function confirmDispatch() {
    st.lastDispatchAt = now();
    st.clickedDispatchAt = 0;
    st.pauseUntil = 0;
    log('3/3', 'janela fechou: venda registrada, recarga de 1 hora');
    try { if (BRIDGE && BRIDGE.dispatched) BRIDGE.dispatched(st.lastDispatchAt); } catch (e) { /* ignora */ }
  }

  async function dispatchFromWindow(win) {
    var btn = findDispatchButton(win);
    if (!btn) { diag('sem-por', 'janela aberta sem botão "Despachar por" utilizável'); return; }
    st.clickedDispatchAt = now();   // marca antes do clique: nunca clicar duas vezes
    clickSynthetic(btn.clickable);
    log('2/3', 'clique em "Despachar por"; aguardando a janela fechar');
    var closed = await waitFor(function () { return !findDispatchWindow(); }, WINDOW_CLOSE_WAIT_MS);
    if (closed) confirmDispatch();
    else diag('nao-fechou', 'janela não fechou após o clique; aguardando, sem clicar de novo');
  }

  // Conta mudanças no DOM. Usado para saber se o clique sintético já mexeu na página
  // (menu abriu); assim o clique nativo não fecha um menu que já abriu.
  function watchMutations() {
    var n = 0;
    var obs = new MutationObserver(function (list) { n += list.length; });
    obs.observe(document.body, { subtree: true, childList: true, attributes: true, characterData: true });
    return {
      stop: function () { n += obs.takeRecords().length; obs.disconnect(); return n; }
    };
  }

  async function openMenuAndDispatch(btn) {
    var watch = watchMutations();
    clickSynthetic(btn.el);
    var item = await waitFor(findMenuItem, 2500);
    var changed = watch.stop() > 0;
    if (!item && !changed) {
      // Nada aconteceu com o clique sintético: usa o clique real.
      clickNative(btn.el);
      item = await waitFor(findMenuItem, 2500);
    }
    if (!item) return pause('item-sem', 'menu aberto mas "Despachar loot" não apareceu');
    if (item.disabled || !item.gold) return pause('item-nao-dourado', '"Despachar loot" não está dourado ou está desabilitado');

    log('1/3', 'menu aberto: clicando em "Despachar loot"');
    clickSynthetic(item.clickable);
    var win = await waitFor(findDispatchWindow, 3000);
    if (!win) {
      clickNative(item.clickable);
      win = await waitFor(findDispatchWindow, 3000);
    }
    if (!win) return pause('janela-sem', 'janela DESPACHAR LOOT não abriu');
    await dispatchFromWindow(win);
  }

  async function runCycle() {
    if (st.clickedDispatchAt) {
      // Já clicamos em "Despachar por": só aguarda a janela fechar, sem clicar de novo.
      if (findDispatchWindow()) {
        diag('aguardando', 'aguardando a janela de despacho fechar');
        return;
      }
      confirmDispatch();
      return;
    }

    var win = findDispatchWindow();
    if (win) { await dispatchFromWindow(win); return; }

    var btn = findGoldenButton();
    if (!btn) { diag('sem-botao', 'botão dourado de venda não encontrado (ainda não disponível?)'); return; }
    if (btn.tie) { diag('empate', 'empate entre botões dourados; não clicando'); return; }
    await openMenuAndDispatch(btn);
  }

  async function cycle() {
    if (!st.enabled || st.running) return;
    var t = now();
    if (t < st.pauseUntil) return;
    if (st.lastDispatchAt && t < st.lastDispatchAt + COOLDOWN_MS) return;
    st.running = true;
    try { await runCycle(); }
    catch (e) { diag('erro', 'erro interno: ' + (e && e.message)); }
    finally { st.running = false; }
  }

  function restartTimer() {
    if (st.timer) clearInterval(st.timer);
    st.timer = null;
    if (st.enabled) {
      st.timer = setInterval(cycle, st.intervalMs);
      cycle();
    }
  }

  // ---------- API pública (chamada pelo app Android) ----------

  window.__hunteraLoot = {
    setEnabled: function (on, cfg) {
      cfg = cfg || {};
      if (cfg.intervalMs) st.intervalMs = Math.max(30000, Number(cfg.intervalMs));
      if (cfg.lastDispatchAt) st.lastDispatchAt = Number(cfg.lastDispatchAt);
      st.enabled = !!on;
      restartTimer();
      return st.enabled;
    },
    setInterval: function (ms) {
      st.intervalMs = Math.max(30000, Number(ms));
      if (st.enabled) restartTimer();
    },
    runNow: function () { return cycle(); },
    status: function () {
      return {
        enabled: st.enabled, running: st.running, intervalMs: st.intervalMs,
        lastDispatchAt: st.lastDispatchAt, clickedDispatchAt: st.clickedDispatchAt,
        pauseUntil: st.pauseUntil
      };
    },
    // Exposto para os testes.
    _internal: {
      parseColor: parseColor, goldScore: goldScore, findGoldenButton: findGoldenButton,
      findMenuItem: findMenuItem, findDispatchWindow: findDispatchWindow, findDispatchButton: findDispatchButton
    }
  };
})();
