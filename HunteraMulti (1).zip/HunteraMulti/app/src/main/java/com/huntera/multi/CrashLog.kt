package com.huntera.multi

import android.content.Context
import android.util.Log
import java.io.File
import java.util.Date

/**
 * Grava erros em um arquivo que pode ser lido depois, mesmo que o app tenha fechado.
 * Caminho no aparelho/emulador:
 *   Android/data/com.huntera.multi/files/huntera_crash.txt
 */
object CrashLog {

    private const val FILE_NAME = "huntera_crash.txt"

    private fun file(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, FILE_NAME)

    /** Registra o handler de exceções. Grava o erro e depois deixa o Android encerrar o app. */
    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            append(app, "CRASH ${Date()} na thread ${thread.name}\n${Log.getStackTraceString(error)}")
            previous?.uncaughtException(thread, error)
        }
    }

    /** Anota um evento não fatal (ex.: processo do WebView morreu). */
    fun note(context: Context, message: String) {
        append(context, "AVISO ${Date()}: $message")
    }

    /** Conteúdo do último registro, ou null se não houver. */
    fun readLast(context: Context): String? {
        val f = file(context)
        return if (f.exists()) f.readText().takeLast(6000) else null
    }

    fun clear(context: Context) {
        file(context).delete()
    }

    private fun append(context: Context, text: String) {
        try {
            file(context).appendText(text + "\n\n")
        } catch (_: Throwable) {
            // Sem armazenamento: nada a fazer além do Logcat.
        }
        Log.e("HunteraMulti", text)
    }
}
