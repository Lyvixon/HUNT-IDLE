package com.huntera.multi

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Preferências e histórico da automação "Venda loot". */
class LootStore(context: Context) {

    private val prefs = context.getSharedPreferences("huntera_loot", Context.MODE_PRIVATE)
    private val lines = ArrayDeque<String>()

    /** Intervalo de verificação em segundos. Padrão 120 s (2 min). */
    var intervalSec: Int
        get() = prefs.getInt("intervalSec", DEFAULT_INTERVAL_SEC)
        set(value) {
            prefs.edit().putInt("intervalSec", value.coerceIn(MIN_INTERVAL_SEC, MAX_INTERVAL_SEC)).apply()
        }

    fun isOn(account: Int): Boolean = prefs.getBoolean("on$account", false)

    fun setOn(account: Int, on: Boolean) {
        prefs.edit().putBoolean("on$account", on).apply()
    }

    /** Último despacho confirmado (epoch ms). Usado para a recarga de 1 hora após reiniciar o app. */
    fun lastDispatchAt(account: Int): Long = prefs.getLong("last$account", 0L)

    fun setLastDispatchAt(account: Int, ts: Long) {
        prefs.edit().putLong("last$account", ts).apply()
    }

    @Synchronized
    fun addLog(line: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        lines.addLast("$stamp  $line")
        while (lines.size > MAX_LINES) lines.removeFirst()
        Log.i(TAG, line)
    }

    @Synchronized
    fun recentLogs(): String = lines.joinToString("\n")

    companion object {
        const val TAG = "HunteraLoot"
        const val DEFAULT_INTERVAL_SEC = 120
        const val MIN_INTERVAL_SEC = 30
        const val MAX_INTERVAL_SEC = 3600
        private const val MAX_LINES = 80
        private const val GAME_HOST = "huntera.com.br"

        /** Só o site do jogo pode acionar a automação pela ponte. */
        fun isGameUrl(url: String?): Boolean {
            val host = Uri.parse(url ?: return false).host ?: return false
            return host == GAME_HOST || host.endsWith(".$GAME_HOST")
        }
    }
}

/**
 * Ponte exposta ao loot.js como window.HunteraLoot (uma por WebView, isto é, por conta).
 * Os métodos anotados com @JavascriptInterface rodam numa thread de fundo;
 * o que mexe na UI ou na WebView é postado na thread principal.
 */
class LootBridge(
    private val account: Int,
    private val webView: WebView,
    private val store: LootStore,
    private val onDispatched: (Int, Long) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun log(step: String, msg: String) {
        val label = if (step.isEmpty()) "" else "[$step] "
        main.post { store.addLog("C${account + 1} $label$msg") }
    }

    @JavascriptInterface
    fun dispatched(ts: Double) {
        main.post {
            if (LootStore.isGameUrl(webView.url)) onDispatched(account, ts.toLong())
        }
    }

    /** Clique real no centro do elemento. Coordenadas em CSS px do viewport da página. */
    @JavascriptInterface
    fun nativeClick(x: Double, y: Double, vw: Double, vh: Double) {
        main.post {
            if (LootStore.isGameUrl(webView.url) && vw > 0 && vh > 0) {
                tap((x * webView.width / vw).toFloat(), (y * webView.height / vh).toFloat())
            }
        }
    }

    private fun tap(px: Float, py: Float) {
        val down = SystemClock.uptimeMillis()
        val downEvent = MotionEvent.obtain(down, down, MotionEvent.ACTION_DOWN, px, py, 0)
        webView.dispatchTouchEvent(downEvent)
        downEvent.recycle()
        main.postDelayed({
            val upEvent = MotionEvent.obtain(down, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, px, py, 0)
            webView.dispatchTouchEvent(upEvent)
            upEvent.recycle()
        }, TAP_DURATION_MS)
    }

    private companion object {
        const val TAP_DURATION_MS = 80L
    }
}
