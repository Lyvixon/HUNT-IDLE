package com.huntera.multi

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private val gameUrl = "https://huntera.com.br"
    // Layout de desktop: o site é desenhado em largura fixa e depois reduzido para caber na célula.
    private val desktopUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val designWidthCss = 1280f

    private lateinit var root: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var webViews: List<WebView>
    private lateinit var buttons: List<Button>

    private val zoomApplied = FloatArray(4) { 1f }
    private var mode = 4
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            android.util.Log.e("HunteraMulti", "Crash", e)
            android.os.Handler(android.os.Looper.getMainLooper()).post { showError("app", e) }
        }

        root = findViewById(R.id.root)
        grid = findViewById(R.id.grid)
        webViews = listOf(
            findViewById(R.id.web1),
            findViewById(R.id.web2),
            findViewById(R.id.web3),
            findViewById(R.id.web4)
        )
        buttons = listOf(
            findViewById(R.id.btn1),
            findViewById(R.id.btn2),
            findViewById(R.id.btn4)
        )

        // Evita que a barra de status e a de navegação cubram o menu ou as contas.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        val multiProfile = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        if (!multiProfile) {
            Toast.makeText(
                this,
                "WebView sem suporte a perfis: as contas podem compartilhar login. Atualize o Android System WebView.",
                Toast.LENGTH_LONG
            ).show()
        }

        webViews.forEachIndexed { index, wv ->
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                userAgentString = desktopUa
                loadWithOverviewMode = true
                useWideViewPort = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                mediaPlaybackRequiresUserGesture = false
            }
            if (multiProfile) {
                // Cada conta tem perfil próprio: cookies, localStorage e sessão isolados.
                val profile = ProfileStore.getInstance().getOrCreateProfile("conta${index + 1}")
                WebViewCompat.setProfile(wv, profile.name)
            }
            wv.webViewClient = WebViewClient()
        }

        buttons[0].setOnClickListener { applyLayout(1) }
        buttons[1].setOnClickListener { applyLayout(2) }
        buttons[2].setOnClickListener { applyLayout(4) }

        // Carrega os sites só depois que o tamanho da grade é conhecido, para calcular o zoom certo.
        grid.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (grid.width > 0 && !loaded) {
                    grid.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    loaded = true
                    loadAll()
                }
            }
        })

        // Sempre que a grade mudar de tamanho (girar, trocar modo), reajusta o zoom sem recarregar.
        grid.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            if (loaded && r - l > 0) grid.post { fitAll() }
        }

        applyLayout(savedInstanceState?.getInt("mode", 4) ?: 4)
    }

    private fun cellWidthPx(): Int = if (mode == 4) grid.width / 2 else grid.width

    private fun targetZoom(): Float {
        val density = resources.displayMetrics.density
        return (cellWidthPx().toFloat() / (designWidthCss * density)).coerceIn(0.2f, 1.5f)
    }

    private fun loadAll() {
        val target = targetZoom()
        webViews.forEachIndexed { i, wv ->
            zoomApplied[i] = target
            wv.settings.setSupportZoom(true)
            wv.setInitialScale((target * 100).toInt().coerceAtLeast(20))
            wv.loadUrl(gameUrl)
        }
    }

    private fun fitAll() {
        try {
            val target = targetZoom()
            for (i in 0 until mode) {
                val wv = webViews[i]
                val factor = target / zoomApplied[i]
                if (kotlin.math.abs(factor - 1f) > 0.01f) {
                    wv.zoomBy(factor)
                    zoomApplied[i] = target
                }
            }
        } catch (e: Throwable) {
            showError("fitAll", e)
        }
    }

    private fun showError(where: String, e: Throwable) {
        val text = "Erro em $where:\n" + e.stackTraceToString().take(3000)
        android.app.AlertDialog.Builder(this)
            .setTitle("Erro no app")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    /** 1 = tela cheia, 2 = empilhadas, 4 = grade 2x2. */
    private fun applyLayout(count: Int) {
        try {
            applyLayoutUnsafe(count)
        } catch (e: Throwable) {
            showError("applyLayout($count)", e)
        }
    }

    private fun applyLayoutUnsafe(count: Int) {
        mode = count
        val (cols, rows) = when (count) {
            1 -> 1 to 1
            2 -> 1 to 2
            else -> 2 to 2
        }
        grid.columnCount = cols
        grid.rowCount = rows

        webViews.forEachIndexed { i, wv ->
            if (i >= count) {
                wv.visibility = View.GONE
                return@forEachIndexed
            }
            wv.visibility = View.VISIBLE
            val row = if (cols == 1) i else i / 2
            val col = if (cols == 1) 0 else i % 2
            wv.layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(row, 1, GridLayout.FILL, 1f),
                GridLayout.spec(col, 1, GridLayout.FILL, 1f)
            ).apply {
                width = 0
                height = 0
                setMargins(2, 2, 2, 2)
            }
        }

        buttons.forEachIndexed { idx, b ->
            val selected = (idx == 0 && count == 1) || (idx == 1 && count == 2) || (idx == 2 && count == 4)
            b.alpha = if (selected) 1f else 0.5f
        }
        grid.requestLayout()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("mode", mode)
    }

    override fun onBackPressed() {
        val focused = webViews.firstOrNull { it.visibility == View.VISIBLE && it.canGoBack() }
        if (focused != null) focused.goBack() else super.onBackPressed()
    }
}
