package com.huntera.multi

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private val gameUrl = "https://huntera.com.br"
    private lateinit var grid: GridLayout
    private lateinit var webViews: List<WebView>
    private var mode = 4

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        webViews = listOf(
            findViewById(R.id.web1),
            findViewById(R.id.web2),
            findViewById(R.id.web3),
            findViewById(R.id.web4)
        )

        val multiProfile = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        if (!multiProfile) {
            Toast.makeText(
                this,
                "WebView sem suporte a perfis: as contas podem compartilhar login. Atualize o Android System WebView.",
                Toast.LENGTH_LONG
            ).show()
        }

        webViews.forEachIndexed { index, wv ->
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(false)
            }
            if (multiProfile) {
                // Cada slot tem seu próprio perfil: cookies, localStorage e sessão isolados.
                val profile = ProfileStore.getInstance().getOrCreateProfile("conta${index + 1}")
                WebViewCompat.setProfile(wv, profile.name)
            }
            wv.webViewClient = WebViewClient()
            wv.loadUrl(gameUrl)
        }

        findViewById<Button>(R.id.btn1).setOnClickListener { applyLayout(1) }
        findViewById<Button>(R.id.btn2).setOnClickListener { applyLayout(2) }
        findViewById<Button>(R.id.btn4).setOnClickListener { applyLayout(4) }

        applyLayout(savedInstanceState?.getInt("mode", 4) ?: 4)
    }

    /** Mostra 1 conta em tela cheia, 2 empilhadas ou 4 em grade 2x2. */
    private fun applyLayout(count: Int) {
        mode = count
        val (cols, rows) = when (count) {
            1 -> 1 to 1
            2 -> 1 to 2
            else -> 2 to 2
        }
        grid.columnCount = cols
        grid.rowCount = rows

        webViews.forEachIndexed { i, wv ->
            if (i >= count) {
                wv.visibility = android.view.View.GONE
                return@forEachIndexed
            }
            wv.visibility = android.view.View.VISIBLE
            val row = if (cols == 1) i else i / 2
            val col = if (cols == 1) 0 else i % 2
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(row, 1, GridLayout.FILL, 1f),
                GridLayout.spec(col, 1, GridLayout.FILL, 1f)
            ).apply {
                width = 0
                height = 0
                setMargins(2, 2, 2, 2)
            }
            wv.layoutParams = lp
        }
        // Em modo 1 a conta visível é a 1; não há outras para o grid distribuir.
        grid.requestLayout()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("mode", mode)
    }

    override fun onBackPressed() {
        val focused = webViews.firstOrNull { it.visibility == android.view.View.VISIBLE && it.canGoBack() }
        if (focused != null) focused.goBack() else super.onBackPressed()
    }
}
