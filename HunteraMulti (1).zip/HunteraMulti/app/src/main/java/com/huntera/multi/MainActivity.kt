package com.huntera.multi

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private val gameUrl = "https://huntera.com.br"
    private val desktopUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val designWidthCss = 1280f

    private lateinit var root: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var accountBox: LinearLayout
    private lateinit var gradeButtons: List<Button>
    private lateinit var accountButtons: List<Button>
    private lateinit var webViews: List<WebView>

    private val zoomApplied = FloatArray(4) { 1f }
    private var mode = 4          // 1, 2 ou 4 contas
    private var selectedAccount = 0 // usado no modo 1 (0..3)
    private var activeIdx: List<Int> = listOf(0, 1, 2, 3)
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            android.util.Log.e("HunteraMulti", "Crash", e)
            Handler(Looper.getMainLooper()).post { showError("app", e) }
        }

        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        grid = findViewById(R.id.grid)
        accountBox = findViewById(R.id.accountBox)
        gradeButtons = listOf(findViewById(R.id.btn1), findViewById(R.id.btn2), findViewById(R.id.btn4))
        accountButtons = listOf(
            findViewById(R.id.acc1), findViewById(R.id.acc2),
            findViewById(R.id.acc3), findViewById(R.id.acc4)
        )

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        val multiProfile = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
        if (!multiProfile) {
            Toast.makeText(
                this,
                "WebView sem suporte a perfis: as contas podem compartilhar login. Atualize o Android System WebView.",
                Toast.LENGTH_LONG
            ).show()
        }

        webViews = List(4) { index -> createWebView(index, multiProfile) }

        gradeButtons[0].setOnClickListener { applyLayout(1, selectedAccount) }
        gradeButtons[1].setOnClickListener { applyLayout(2, selectedAccount) }
        gradeButtons[2].setOnClickListener { applyLayout(4, selectedAccount) }
        accountButtons.forEachIndexed { idx, b ->
            b.setOnClickListener { applyLayout(1, idx) }
        }

        // Carrega as contas só depois que o tamanho da área já é conhecido, para calcular o zoom.
        grid.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (grid.width > 0 && !loaded) {
                    grid.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    loaded = true
                    loadAll()
                }
            }
        })

        // Ao mudar o tamanho da área (girar, trocar modo), só reajusta o zoom. Não recarrega.
        grid.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            if (loaded && r - l > 0) grid.post { fitAll() }
        }

        val savedMode = savedInstanceState?.getInt("mode", 4) ?: 4
        val savedAcc = savedInstanceState?.getInt("acc", 0) ?: 0
        applyLayout(savedMode, savedAcc)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(index: Int, multiProfile: Boolean): WebView {
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            userAgentString = desktopUa
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        if (multiProfile) {
            // Cada conta tem perfil próprio: cookies, localStorage e sessão isolados.
            val profile = ProfileStore.getInstance().getOrCreateProfile("conta${index + 1}")
            WebViewCompat.setProfile(wv, profile.name)
        }
        wv.webViewClient = WebViewClient()
        return wv
    }

    /** Largura de referência de uma conta na tela atual. */
    private fun cellWidthPx(): Int = if (mode == 4) grid.width / 2 else grid.width

    private fun targetZoom(): Float {
        val density = resources.displayMetrics.density
        return (cellWidthPx().toFloat() / (designWidthCss * density)).coerceIn(0.2f, 1.5f)
    }

    private fun loadAll() {
        val target = targetZoom()
        webViews.forEachIndexed { i, wv ->
            zoomApplied[i] = target
            wv.setInitialScale((target * 100).toInt().coerceAtLeast(20))
            wv.loadUrl(gameUrl)
        }
    }

    private fun fitAll() {
        try {
            val target = targetZoom()
            for (i in activeIdx) {
                val wv = webViews[i]
                val factor = target / zoomApplied[i]
                if (abs(factor - 1f) > 0.01f) {
                    wv.zoomBy(factor)
                    zoomApplied[i] = target
                }
            }
        } catch (e: Throwable) {
            showError("ajuste de zoom", e)
        }
    }

    /** mode: 1 = uma conta (escolhida em [account]), 2 = contas 1 e 2, 4 = contas 1 a 4. */
    private fun applyLayout(newMode: Int, account: Int) {
        try {
            mode = newMode
            selectedAccount = account
            activeIdx = when (mode) {
                1 -> listOf(selectedAccount)
                2 -> listOf(0, 1)
                else -> listOf(0, 1, 2, 3)
            }

            // Remove as linhas antigas e recria a estrutura do zero, sem GridLayout.
            grid.removeAllViews()
            val rows: List<List<Int>> = when (mode) {
                1 -> listOf(listOf(selectedAccount))
                2 -> listOf(listOf(0), listOf(1))
                else -> listOf(listOf(0, 1), listOf(2, 3))
            }

            rows.forEach { rowAccounts ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                rowAccounts.forEach { i ->
                    val wv = webViews[i]
                    (wv.parent as? ViewGroup)?.removeView(wv)
                    row.addView(
                        wv,
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                            setMargins(2, 2, 2, 2)
                        }
                    )
                }
            }

            accountBox.visibility = if (mode == 1) View.VISIBLE else View.GONE
            val gradeIdx = when (mode) { 1 -> 0; 2 -> 1; else -> 2 }
            gradeButtons.forEachIndexed { idx, b -> b.alpha = if (idx == gradeIdx) 1f else 0.5f }
            accountButtons.forEachIndexed { idx, b -> b.alpha = if (mode == 1 && idx == selectedAccount) 1f else 0.5f }

            grid.requestLayout()
            if (loaded) grid.post { fitAll() }
        } catch (e: Throwable) {
            showError("trocar grade", e)
        }
    }

    private fun showError(where: String, e: Throwable) {
        val text = "Erro em $where:\n" + e.stackTraceToString().take(3000)
        android.app.AlertDialog.Builder(this)
            .setTitle("Erro no app")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("mode", mode)
        outState.putInt("acc", selectedAccount)
    }

    override fun onBackPressed() {
        val focused = activeIdx.map { webViews[it] }.firstOrNull { it.canGoBack() }
        if (focused != null) focused.goBack() else super.onBackPressed()
    }
}
